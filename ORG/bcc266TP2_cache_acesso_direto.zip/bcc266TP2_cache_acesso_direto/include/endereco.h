#ifndef ENDERECO_H
#define ENDERECO_H

typedef struct {
    int endBloco;
    int endPalavra;
} Endereco;

#endif // ENDERECO_H