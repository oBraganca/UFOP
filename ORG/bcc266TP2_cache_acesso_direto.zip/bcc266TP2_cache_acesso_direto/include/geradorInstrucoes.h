
#ifndef GERADOR_INSTRUCOES_H
#define GERADOR_INSTRUCOES_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


#define QTD_INS 10000
#define TAM_FOR 3
#define TAM_MEM 1000
#define PROB_FOR 95

    void GeradorInstrucoes();

#endif // GERADOR_INSTRUCOES_H