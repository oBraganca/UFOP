#ifndef ORDENACAO_H
#define ORDENACAO_H

//Manter como especificado
int* alocaVetor(int n);

//Manter como especificado
int* desalocaVetor(int* v);

//Manter como especificado
void ordenacao(int* v, int n, int* movimentos);

#endif // ORDENACAO_H
