#ifndef RECURSAO_H
#define RECURSAO_H

// Mantenha como especificado
// Calcula o Maximo Divisor Comum
int mdc(int x, int y);

// Calcula o Minimo Multiplo Comum
int mmc(int x, int y);

#endif