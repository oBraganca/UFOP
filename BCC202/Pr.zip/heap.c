#include "heap.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/** Mantenha como especificado
 * Refaz o heap da raiz para as folhas
 */ 
void refaz(Heap *heap);

/** Mantenha como especificado
 * Insere um chamada na posicao index
 */ 
void heapInsere(Heap *heap, Chamada chamada, int index);

/** Mantenha como especificado
 * Retorna true se c1 tem mais prioridade do que c2.
 * Se forem iguais, retorne false
 */ 
bool temMaisPrioridade(Chamada* c1, Chamada* c2);

// Mantenha como especificado
Chamada criarChamada(char *nome, int prioridade, int dia, int mes, int ano) {
    /* Preencher aqui */
}

// Mantenha como especificado
void imprimeChamada(Chamada chamada) {
    printf("%02d | %02d/%02d/%04d | %s\n", chamada.prioridade, chamada.nascimento.dia,
            chamada.nascimento.mes, chamada.nascimento.ano, chamada.nome);
}

// Mantenha como especificado
Heap* criarHeap() {
    /* Preencher aqui */
}

// Mantenha como especificado
Heap* destroiHeap(Heap *heap) {
    /* Preencher aqui */
}

// Mantenha como especificado
void inserirChamada(Heap *heap, Chamada chamada) {
    /* Preencher aqui */
    // A posicao que deve-se inserir no heap eh na primeira posicao vazia do heap
    // Chame a funcao heapInsere
}

// Mantenha como especificado
Chamada atenderChamada(Heap *heap) {
    /* Preencher aqui */
    // Remover a chamada com maior prioridade do heap
}

// Mantenha como especificado
bool consultarSeTemProximaChamada(Heap *heap) {
    /* Preencher aqui */
    // Verifica se tem o heap tem pelo menos uma chamada
}

// Mantenha como especificado
void refaz(Heap *heap) {
    /* Preencher aqui */
}

// Mantenha como especificado
void heapInsere(Heap *heap, Chamada chamada, int index) {
    /* Preencher aqui */
}

// Mantenha como especificado
bool temMaisPrioridade(Chamada* c1, Chamada* c2) {
    /* Preencher aqui */
}